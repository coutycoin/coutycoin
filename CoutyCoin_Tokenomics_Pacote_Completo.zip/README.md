
# CoutyCoin - CTY Token
Token lançado na BNB Smart Chain para promover inclusão financeira e engajamento cripto.
- Website: https://coutycoin.com.br
- Contrato: 0xdD516b23e81F86f032Ce8e577D41890f18Fb7deE
- Compilado com Solidity 0.8.24 no Remix IDE
- Whitepaper incluso
